from fastapi import APIRouter, HTTPException, status
import schemas
import services

router = APIRouter(prefix="/recursos-humanos", tags=["Recursos Humanos"])

EMPLEADOS_DB = {
"1001": {"nombre": "Ana", "salario_hora": 15000},
"1002": {"nombre": "Carlos", "salario_hora": 25000},
"1003": {"nombre": "María", "salario_hora": 12000}
}

@router.post("/nomina")
def liquidar_nomina(peticion: schemas.PeticionNomina):
    try:
        resultado = services.calcular_nomina(
            peticion=peticion,
            empleados_bd=EMPLEADOS_DB
        )
        return resultado
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
