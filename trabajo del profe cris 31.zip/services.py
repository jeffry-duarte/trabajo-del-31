def calcular_nomina(peticion, empleados_bd):

    total_nomina_empresa = 0.0
    detalle_pagos = []

    for trabajador in peticion.trabajadores:
        if trabajador.documento not in empleados_bd:
            raise ValueError(f"El empleado {trabajador.documento} no existe en la base de datos")

        salario_hora = empleados_bd[trabajador.documento]["salario_hora"]
        salario_base = trabajador.horas_trabajadas * salario_hora
        salario_final = salario_base

        if trabajador.horas_trabajadas > 160:
            horas_extras = trabajador.horas_trabajadas - 160
            recargo = horas_extras * salario_hora * 0.25
            salario_final = salario_final + recargo

        if trabajador.tipo_contrato == "FIJO":
            deduccion = salario_base * 0.08
            salario_final = salario_final - deduccion

        if salario_final < 2000000:
            salario_final = salario_final + 162000

        total_nomina_empresa = total_nomina_empresa + salario_final

        detalle_pagos.append({
            "documento": trabajador.documento,
            "total_a_pagar": salario_final
        })

    return {
        "total_nomina_empresa": total_nomina_empresa,
        "detalle_pagos": detalle_pagos
    }
