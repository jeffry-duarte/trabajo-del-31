from pydantic import BaseModel
from typing import List, Literal

class ReporteTiempo(BaseModel):
    documento: str
    horas_trabajadas: int
    tipo_contrato: Literal["FIJO", "PRESTACION"]

class PeticionNomina(BaseModel):
    mes_liquidacion: str
    trabajadores: List[ReporteTiempo]
