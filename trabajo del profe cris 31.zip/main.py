from fastapi import FastAPI
from routers import recursos_humanos

app = FastAPI(title="API con capa de servicios")
app.include_router(recursos_humanos.router)

@app.get("/")
def raiz():
    return {"mensaje": "Servidor corriendo. Ve a /docs para probar la nomina."}
